#!/usr/bin/env bash
# This file will contain functions related to gathering stats and displaying it for agent
# Agent will have to call mmp-stats.sh which will contain triggers for configuration files and etc.
# Do not add anything static in this file
GPU_COUNT=$1
LOG_FILE=$2
cd `dirname $0`
API_TIMEOUT=120
MINER_API_PORT=32159

stats_raw=$(curl --connect-timeout 2 --max-time ${API_TIMEOUT} --silent --noproxy '*' http://127.0.0.1:${MINER_API_PORT})
stats=$(jq '{index: [.threads[].id], busid: [.threads[].bus], hash: [.threads[].hr|tonumber], air: .air, units: "hs", miner_name: .miner_name, miner_version: .version}' <<< $stats_raw)
echo $stats
